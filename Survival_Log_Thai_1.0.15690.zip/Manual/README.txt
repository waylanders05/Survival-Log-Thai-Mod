Manual patch for Survival Log 1.0.15690.
Copy the contents of the Manual folder into the game folder after making backups.
