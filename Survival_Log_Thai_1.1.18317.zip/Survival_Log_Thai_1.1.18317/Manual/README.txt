Manual patch for Survival Log 1.1.18317.
Copy the contents of the Manual folder into the game folder after making backups.
