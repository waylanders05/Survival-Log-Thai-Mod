Manual patch for Survival Log 1.1.20719.
Copy the contents of the Manual folder into the game folder after making backups.
