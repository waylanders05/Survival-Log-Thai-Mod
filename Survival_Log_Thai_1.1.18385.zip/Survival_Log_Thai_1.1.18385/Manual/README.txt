Manual patch for Survival Log 1.1.18385.
Copy the contents of the Manual folder into the game folder after making backups.
