Manual patch for Survival Log 1.1.20151.
Copy the contents of the Manual folder into the game folder after making backups.
